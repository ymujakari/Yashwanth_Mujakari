package com.alibaba.excel.converters;

/**
 * An empty converter.It's automatically converted by type.
 *
 * @author Jiaju Zhuang
 */
public class AutoConverter implements Converter<Object> {
}
