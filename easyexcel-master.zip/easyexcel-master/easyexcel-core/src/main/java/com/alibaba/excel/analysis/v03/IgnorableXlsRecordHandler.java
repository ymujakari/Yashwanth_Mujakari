package com.alibaba.excel.analysis.v03;

/**
 * Need to ignore the current handler without reading the current sheet.
 *
 * @author Jiaju Zhuang
 */
public interface IgnorableXlsRecordHandler extends XlsRecordHandler {}
