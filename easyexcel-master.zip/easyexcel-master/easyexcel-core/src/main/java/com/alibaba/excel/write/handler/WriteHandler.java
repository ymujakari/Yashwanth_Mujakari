package com.alibaba.excel.write.handler;

import com.alibaba.excel.event.Handler;

/**
 * intercepts handle excel write
 *
 * @author Jiaju Zhuang
 */
public interface WriteHandler extends Handler {}
