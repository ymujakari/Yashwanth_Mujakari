package com.alibaba.excel.event;

/**
 * Interface to listen for processing results
 *
 * @author Jiaju Zhuang
 */
public interface Listener {}
