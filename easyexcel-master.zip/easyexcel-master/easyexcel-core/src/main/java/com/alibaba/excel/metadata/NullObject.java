package com.alibaba.excel.metadata;

/**
 * Null object.
 *
 * @author Jiaju Zhuang
 */
public class NullObject {
}
