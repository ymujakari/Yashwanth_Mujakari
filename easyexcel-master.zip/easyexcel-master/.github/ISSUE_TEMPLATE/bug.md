---
name: bug
about: 发现一个新的Bug
title: ''
labels: bug
assignees: zhuangjiaju

---

# 建议先去看文档
[快速开始](https://easyexcel.opensource.alibaba.com/docs/current/) 、[常见问题](https://easyexcel.opensource.alibaba.com/qa/)
# 触发场景描述

# 触发Bug的代码
```java
   这里写代码
```
# 提示的异常或者没有达到的效果
大家尽量把问题一次性描述清楚，然后贴上全部异常，这样方便把问题一次性解决掉。
至少大家要符合一个原则就是，能让其他人复现出这个问题，如果无法复现，肯定无法解决。
