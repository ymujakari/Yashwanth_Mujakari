package com.alibaba.easyexcel.test.core.large;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Jiaju Zhuang
 */
@Getter
@Setter
@EqualsAndHashCode
public class LargeData {

    private String str1;

    private String str2;

    private String str3;

    private String str4;

    private String str5;

    private String str6;

    private String str7;

    private String str8;

    private String str9;

    private String str10;

    private String str11;

    private String str12;

    private String str13;

    private String str14;

    private String str15;

    private String str16;

    private String str17;

    private String str18;

    private String str19;

    private String str20;

    private String str21;

    private String str22;

    private String str23;

    private String str24;

    private String str25;
}
