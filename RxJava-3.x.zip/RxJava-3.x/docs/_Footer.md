**Copyright (c) 2016-present, RxJava Contributors.**  
[Twitter @RxJava](https://twitter.com/#!/RxJava) | [Gitter @RxJava](https://gitter.im/ReactiveX/RxJava)
