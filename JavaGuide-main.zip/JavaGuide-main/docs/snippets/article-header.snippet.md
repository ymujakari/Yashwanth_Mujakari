[![JavaGuide官方知识星球](https://oss.javaguide.cn/xingqiu/xingqiu.png)](../about-the-author/zhishixingqiu-two-years.md)
