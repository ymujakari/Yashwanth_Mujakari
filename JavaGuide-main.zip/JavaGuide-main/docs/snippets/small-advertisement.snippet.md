::: tip 这是一则或许对你有用的小广告

- **面试专版**：准备 Java 面试的小伙伴可以考虑面试专版：**[《Java 面试指北 》](../zhuanlan/java-mian-shi-zhi-bei.md)** (质量非常高，专为面试打造，配合 JavaGuide 食用效果最佳)。
- **知识星球**：技术专栏/一对一提问/简历修改/求职指南/面试打卡/不定时福利，欢迎加入 **[JavaGuide 官方知识星球](../about-the-author/zhishixingqiu-two-years.md)**。

:::
