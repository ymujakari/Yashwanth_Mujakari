---
title: 抄袭狗，你冬天睡觉脚必冷！！！
category: 走近作者
tag:
  - 杂谈
---

抄袭狗真的太烦了。。。

听朋友说我的文章在知乎又被盗了，原封不动地被别人用来引流。

![](https://oss.javaguide.cn/p3-juejin/39f223bd8d8240b8b7328f7ab6edbc57~tplv-k3u1fbpfcp-zoom-1.png)

而且！！！这还不是最气的。

这人还在文末注明的原出处还不是我的。。。

![](https://oss.javaguide.cn/p3-juejin/fa47e0752f4b4b57af424114bc6bc558~tplv-k3u1fbpfcp-zoom-1.png)

也就是说 CSDN 有另外一位抄袭狗盗了我的这篇文章并声明了原创，知乎抄袭狗又原封不动地搬运了这位 CSDN 抄袭狗的文章。

真可谓离谱他妈给离谱开门，离谱到家了。

![](https://oss.javaguide.cn/p3-juejin/6f8d281579224b13ad235c28e1d7790e~tplv-k3u1fbpfcp-zoom-1.png)

我打开知乎抄袭狗注明的原出处链接，好家伙，一模一样的内容，还表明了原创。

![](https://oss.javaguide.cn/p3-juejin/6a6d7b206b6a43ec9b0055a8f47a30be~tplv-k3u1fbpfcp-zoom-1.png)

看了一下 CSDN 这位抄袭狗的文章，好家伙，把我高赞回答搬运了一个遍。。。真是很勤奋了。。。

CSDN 我就不想多说了，就一大型文章垃圾场，都是各种不规范转载，各种收费下载的垃圾资源。这号称国内流量最大的技术网站贼恶心，吃香太难看，能不用就不要用吧！

像我自己平时用 Google 搜索的时候，都是直接屏蔽掉 CSDN 这个站点的。只需要下载一个叫做 Personal Blocklist 的 Chrome 插件，然后将 blog.csdn.net 添加进黑名单就可以了。

![](https://oss.javaguide.cn/p3-juejin/be151d93cd024c6e911d1a694212d91c~tplv-k3u1fbpfcp-zoom-1.png)

我的文章基本被盗完了，关键是我自己发没有什么流量，反而是盗我文章的那些人比我这个原作者流量还大。

这是什么世道，是人性的扭曲还是道德的沦丧？

不过，也没啥，CSDN 这垃圾网站不去发文也无妨。

看看 CSDN 热榜上的文章都是一些什么垃圾，不是各种广告就是一些毫无质量的拼凑文。

![](https://oss.javaguide.cn/p3-juejin/cd07efe86af74ea0a07d29236718ddc8~tplv-k3u1fbpfcp-zoom-1-20230717155426403.png)

当然了，也有极少部分的高质量文章，比如涛哥、二哥、冰河、微观技术等博主的文章。

还有很多视频平台（比如抖音、哔哩哔哩）上面有很多博主直接把别人的原创拿来做个视频，用来引流或者吸粉。

今天提到的这篇被盗的文章曾经就被一个培训机构拿去做成了视频用来引流。

![](https://oss.javaguide.cn/p3-juejin/9dda1e36ceff4cbb9b0bf9501b279be5~tplv-k3u1fbpfcp-zoom-1.png)

作为个体，咱也没啥办法，只能遇到一个举报一个。。。
