---
title: PriorityQueue 源码分析（付费）
category: Java
tag:
  - Java集合
---

**PriorityQueue 源码分析** 为我的[知识星球](https://javaguide.cn/about-the-author/zhishixingqiu-two-years.html)（点击链接即可查看详细介绍以及加入方法）专属内容，已经整理到了[《Java 必读源码系列》](https://javaguide.cn/zhuanlan/source-code-reading.html)中。

![PriorityQueue 源码分析](https://oss.javaguide.cn/xingqiu/image-20230727084055593.png)

<!-- @include: @yuanma.snippet.md -->

<!-- @include: @article-footer.snippet.md -->
