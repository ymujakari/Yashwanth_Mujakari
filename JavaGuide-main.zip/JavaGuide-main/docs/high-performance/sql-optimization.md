---
title: 常见SQL优化手段总结（付费）
category: 高性能
head:
  - - meta
    - name: keywords
      content: 分页优化,索引,Show Profile,慢 SQL
  - - meta
    - name: description
      content: SQL 优化是一个大家都比较关注的热门话题，无论你在面试，还是工作中，都很有可能会遇到。如果某天你负责的某个线上接口，出现了性能问题，需要做优化。那么你首先想到的很有可能是优化 SQL 优化，因为它的改造成本相对于代码来说也要小得多。
---

**常见 SQL 优化手段总结** 相关的内容为我的[知识星球](https://javaguide.cn/about-the-author/zhishixingqiu-two-years.html)（点击链接即可查看详细介绍以及加入方法）专属内容，已经整理到了[《Java 面试指北》](https://javaguide.cn/zhuanlan/java-mian-shi-zhi-bei.html)中。

![](https://oss.javaguide.cn/javamianshizhibei/sql-optimization.png)

<!-- @include: @planet.snippet.md -->

<!-- @include: @article-footer.snippet.md -->
