---
title: Redis集群详解(付费)
category: 数据库
tag:
  - Redis
---

**Redis 集群** 相关的面试题为我的 [知识星球](../../about-the-author/zhishixingqiu-two-years.md)（点击链接即可查看详细介绍以及加入方法）专属内容，已经整理到了[《Java 面试指北》](../../zhuanlan/java-mian-shi-zhi-bei.md)中。

![](https://oss.javaguide.cn/github/javaguide/database/redis/redis-cluster-javamianshizhibei.png)

<!-- @include: @planet.snippet.md -->

<!-- @include: @article-footer.snippet.md -->
